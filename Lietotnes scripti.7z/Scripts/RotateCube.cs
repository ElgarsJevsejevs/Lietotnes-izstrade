using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotateCube : MonoBehaviour
{
    float rotationSpeed = 2f;
    float rotationSpeedTouch = 0.2f;

    private LineRenderer lineRenderer;
    private void OnMouseDrag()
    {
        float XaxisRotation = Input.GetAxis("Mouse X") * rotationSpeed;
        float YaxisRotation = Input.GetAxis("Mouse Y") * rotationSpeed;

        transform.Rotate(Vector3.down, XaxisRotation);
        transform.Rotate(Vector3.right, YaxisRotation);
    }
    private void Update()
    {
        if (Input.touchCount == 1)
        {
            Touch touch = Input.GetTouch(0);
            if (touch.phase == TouchPhase.Moved)
            {
                float XaxisRotation = touch.deltaPosition.x * rotationSpeedTouch;
                float YaxisRotation = touch.deltaPosition.y * rotationSpeedTouch;

                transform.Rotate(Vector3.down, XaxisRotation);
                transform.Rotate(Vector3.right, YaxisRotation);
            }
        }
        if (Input.GetMouseButtonDown(0) || Input.touchCount > 0 && Input.GetTouch(0).phase == TouchPhase.Began)
        {

            Vector3 touchPos = Vector3.zero;
            if (Input.touchCount > 0)
            {
                touchPos = Input.GetTouch(0).position;
            }
            else if (Input.GetMouseButtonDown(0))
            {
                touchPos = Input.mousePosition;
            }

        }
    }
}


