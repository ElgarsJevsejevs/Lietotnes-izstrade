using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CreateFigureMore : MonoBehaviour
{
    public GameObject pointPrefab2;
    public Transform pointParent2;
    public int maxPoints2 = 2;

    private int pointCount2 = 0;
    private List<Vector3> points2 = new List<Vector3>();
    private LineRenderer lineRenderer2;
    private bool isCreating2 = false;

    public InputField maxPointsInput;

    private void Start()
    {

        if (pointParent2 == null)
        {
            pointParent2 = transform;
        }
        maxPointsInput.onValueChanged.AddListener(OnMaxPointsValueChanged);
        lineRenderer2 = gameObject.AddComponent<LineRenderer>();
        lineRenderer2.startWidth = 1f;
        lineRenderer2.endWidth = 1f;
        lineRenderer2.positionCount = 0;
        lineRenderer2.material = new Material(Shader.Find("Sprites/Default"));
        lineRenderer2.material.color = UnityEngine.Color.black;

    }
    public void StartCreating2()
    {
        isCreating2 = true;
    }

    private void OnMaxPointsValueChanged(string newValue)
    {
        if (int.TryParse(newValue, out int result))
        {
            maxPoints2 = result;
        }
    }

    private void Update()
    {
        if (isCreating2 && Input.GetMouseButtonDown(0) && pointCount2 < maxPoints2)
        {
            Vector3 mousePos = Camera.main.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, Input.mousePosition.y, Camera.main.nearClipPlane));

            GameObject newPoint2 = Instantiate(pointPrefab2, mousePos, Quaternion.identity, pointParent2);

            points2.Add(newPoint2.transform.position);

            lineRenderer2.positionCount = points2.Count;
            lineRenderer2.SetPositions(points2.ToArray());

            if (pointCount2 == maxPoints2 - 1)
            {
                lineRenderer2.positionCount++;
                lineRenderer2.SetPosition(lineRenderer2.positionCount - 1, points2[0]);
            }

            pointCount2++;
        }
    }

    public void ClearPoints2()
    {
        
        pointCount2 = 0;
        points2.Clear();
        lineRenderer2.positionCount = 0;

        foreach (Transform child in pointParent2)
        {
            Destroy(child.gameObject);
        }

        isCreating2 = false;
    }
}