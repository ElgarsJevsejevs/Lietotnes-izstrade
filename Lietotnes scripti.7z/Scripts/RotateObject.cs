using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotateObject : MonoBehaviour
{
    public float speed = 10f;
    public float angle;

    void Update()
    {
        transform.Rotate(angle, speed * Time.deltaTime, 0);
    }
}
