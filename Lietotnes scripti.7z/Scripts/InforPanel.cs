using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InforPanel : MonoBehaviour
{

    public GameObject Panel;
    public GameObject Panel2;
    public GameObject Panel3;
    public GameObject Panel4;

    public void OpenPanel()
    {
        if (Panel != null)
        {
            bool isActive = Panel.activeSelf;
            
            Panel.SetActive(!isActive);
        }
    }

    public void NextPanel()
    {
        Panel.SetActive(false);
        Panel2.SetActive(true);

    }
    public void NextPanel2()
    {
        Panel2.SetActive(false);
        Panel3.SetActive(true);

    }
    public void NextPanel3()
    {
        Panel3.SetActive(false);
        Panel4.SetActive(true);

    }
    public void PrevPanel()
    {

        Panel2.SetActive(false);
        Panel.SetActive(true);

    }
    public void PrevPanel2()
    {

        Panel3.SetActive(false);
        Panel2.SetActive(true);

    }
    public void PrevPanel3()
    {

        Panel4.SetActive(false);
        Panel3.SetActive(true);

    }

    public void Close()
    {
        Panel3.SetActive(false);
    }
    public void Close1()
    {
        Panel.SetActive(false);
    }
    public void Close2()
    {
        Panel4.SetActive(false);
    }
    public void Close3()
    {
        if (Panel != null)
        {
            bool isActive = Panel.activeSelf;

            Panel.SetActive(!isActive);
        }
    }

}
