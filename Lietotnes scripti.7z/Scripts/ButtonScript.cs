using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButtonScript : MonoBehaviour
{
    public GameObject cubeObject;
    private MeshMovement cubeScript;

    private void Start()
    {
        cubeScript = cubeObject.GetComponent<MeshMovement>();
    }

    public void OnButtonClick()
    {
        if (cubeScript == null)
        {
            cubeScript = cubeObject.AddComponent<MeshMovement>();
        }

        cubeObject.SetActive(!cubeObject.activeSelf);

        if (cubeObject.activeSelf)
        {
            cubeScript.CubePoints();
            cubeScript.CubeLines();
        }
    }
}