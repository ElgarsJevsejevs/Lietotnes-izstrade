using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LineDrawer : MonoBehaviour
{
    private LineRenderer lineRenderer;
    private Vector3 mousePos;
    private Vector3 startMouse;

    [SerializeField]
    private Text distanceText;

    private float distance;

    private bool isCreating = false;

    void Start()
    {
        lineRenderer = GetComponent<LineRenderer>();
        lineRenderer.positionCount = 2;
    }

    public void Measure()
    {
        isCreating = !isCreating;

    }

    void Update()
    {
        if (isCreating)
        {
            if (Input.GetMouseButtonDown(0))
            {
                startMouse = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            }

            if (Input.GetMouseButton(0))
            {

                mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
                lineRenderer.SetPosition(0, new Vector3(startMouse.x, startMouse.y, 0f));
                lineRenderer.SetPosition(1, new Vector3(mousePos.x, mousePos.y, 0f));
                distance = (mousePos - startMouse).magnitude;
                distanceText.text = distance.ToString("F2") + " cm";
            }
        }
    }
}
