using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Scalevalues : MonoBehaviour
{
    public InputField scaleInputFieldx;
    public InputField scaleInputFieldy;
    public InputField scaleInputFieldz;

    private Transform cubeTransform;
    private Transform pyramidTransfrom;

    void Start()
    {
        cubeTransform = gameObject.GetComponent<Transform>();
        pyramidTransfrom = gameObject.GetComponent<Transform>();
    }

    public void OnScaleButtonClicked()
    {
        float scalex = float.Parse(scaleInputFieldx.text);
        float scaley = float.Parse(scaleInputFieldy.text);
        float scalez = float.Parse(scaleInputFieldz.text);
        cubeTransform.localScale = new Vector3(scalex, scaley, scalez);
    }

    public void OnScaleButtonClicked2()
    {
        float scalex = float.Parse(scaleInputFieldx.text);
        float scaley = float.Parse(scaleInputFieldy.text);
        float scalez = float.Parse(scaleInputFieldz.text);

        pyramidTransfrom.localScale = new Vector3(scalex, scaley, scalez);
    }

}