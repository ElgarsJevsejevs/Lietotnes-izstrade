using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ValueChecker : MonoBehaviour
{
    public float referenceValue;
    public InputField inputField;
    private Transform cubeTransform;
    public GameObject pictrue;
    public GameObject picfalse;

    private Transform pyramidTransform;

    private Transform cylinderTransform;

    void Start()
    {
        cubeTransform = gameObject.GetComponent<Transform>();
        pyramidTransform = gameObject.GetComponent<Transform>();
        cylinderTransform = gameObject.GetComponent<Transform>();
    }
    public void CheckValue()
    {
        float perimeter = 12 * cubeTransform.localScale.x;
        float enteredValue;


        if (float.TryParse(inputField.text, out enteredValue))
        {
            if (Mathf.Approximately(enteredValue, perimeter))
            {
                inputField.text += " Pareizi!";
                pictrue.SetActive(true);
                picfalse.SetActive(false);


            }
            else
            {
                inputField.text += " Nepareizi!";
                pictrue.SetActive(false);
                picfalse.SetActive(true);
            }
        }
    }

    public void CheckValue2()
    {
        float perimeter = (pyramidTransform.localScale.x * pyramidTransform.localScale.z);

        float enteredValue;

        if (float.TryParse(inputField.text, out enteredValue))
        {
            if (Mathf.Approximately(enteredValue, perimeter))
            {
                inputField.text += " Pareizi!";
                pictrue.SetActive(true);
                picfalse.SetActive(false);


            }
            else
            {
                inputField.text += " Nepareizi!";
                pictrue.SetActive(false);
                picfalse.SetActive(true);
            }
        }
    }
    public void CheckValue3()
    {
        float perimeter = 16 * cylinderTransform.localScale.z;

        float enteredValue;

        if (float.TryParse(inputField.text, out enteredValue))
        {
            if (cylinderTransform.localScale.x == cylinderTransform.localScale.y && cylinderTransform.localScale.x == cylinderTransform.localScale.z
                && cylinderTransform.localScale.y == cylinderTransform.localScale.z)
            {
                if (Mathf.Approximately(enteredValue, perimeter))
                {
                    inputField.text += " Pareizi!";
                    pictrue.SetActive(true);
                    picfalse.SetActive(false);


                }
                else
                {
                    inputField.text += " Nepareizi!";
                    pictrue.SetActive(false);
                    picfalse.SetActive(true);
                }
            }
            else { inputField.text += " Nav regul�rs"; 
            }
        }
    }
}
