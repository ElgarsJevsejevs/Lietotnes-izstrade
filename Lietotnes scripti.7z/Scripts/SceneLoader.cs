using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneLoader : MonoBehaviour
{
    public string sceneName;
    public void LoadNextScene()
    {
        int currentSceneIndex = SceneManager.GetActiveScene().buildIndex;
        SceneManager.LoadScene(currentSceneIndex + 1);
    }

    public void LoadStartScene()
    {
        SceneManager.LoadScene(0);
    }
    public void LoadPrevoisScene()
    {
        int currentSceneIndex = SceneManager.GetActiveScene().buildIndex;
        SceneManager.LoadScene(currentSceneIndex - 1);
    }
    public void LoadStart()
    {
        SceneManager.LoadScene("StartScene");
    }
    public void LoadCube()
    {
        SceneManager.LoadScene("Cube");
    }
    public void LoadCube2()
    {
        SceneManager.LoadScene("Cube_2");
    }
    public void LoadCylinder()
    {
        SceneManager.LoadScene("Cylinder");
    }
    public void LoadTriangle()
    {
        SceneManager.LoadScene("Triangle");
    }
    public void LoadTriangle2()
    {
        SceneManager.LoadScene("Triangle 2");
    }
    public void LoadScene1()
    {
        SceneManager.LoadScene("CubeAnimation1");
    }
    public void LoadScene2()
    {
        SceneManager.LoadScene("CubeAnimation2");
    }
    public void LoadScene3()
    {
        SceneManager.LoadScene("CubeAnimation3");
    }
    public void LoadScene4()
    {
        SceneManager.LoadScene("CubeAnimation4");
    }
    public void LoadScene5()
    {
        SceneManager.LoadScene("CubeAnimation5");
    }

    public void LoadSceneT1()
    {
        SceneManager.LoadScene("TriangleAnimation1");
    }
    public void LoadSceneT2()
    {
        SceneManager.LoadScene("TriangleAnimation2");
    }
    public void LoadSceneT3()
    {
        SceneManager.LoadScene("TriangleAnimation3");
    }
    public void LoadSceneT4()
    {
        SceneManager.LoadScene("TriangleAnimation4");
    }
    public void LoadSceneT5()
    {
        SceneManager.LoadScene("TriangleAnimation5");
    }
    public void LoadTasks()
    {
        SceneManager.LoadScene("Tasks1");
    }
    public void LoadTasks1()
    {
        SceneManager.LoadScene("Tasks2");
    }
    public void LoadTasks2()
    {
        SceneManager.LoadScene("Tasks3");
    }
    public void LoadTasks3()
    {
        SceneManager.LoadScene("Tasks4");
    }
    public void LoadNext()
    {
        SceneManager.LoadScene(sceneName);
    }
    public void LoadTasksPic2()
    {
        SceneManager.LoadScene("Tasks2 1");
    }
    public void LoadTasksPic3()
    {
        SceneManager.LoadScene("Tasks2 2");
    }
    public void LoadTasksGrid()
    {
        SceneManager.LoadScene("Tasks Grid");
    }
    public void LoadTasksGrid2()
    {
        SceneManager.LoadScene("Tasks Grid 1");
    }
    public void LoadTasksGrid3()
    {
        SceneManager.LoadScene("Tasks Grid 2");
    }
}
