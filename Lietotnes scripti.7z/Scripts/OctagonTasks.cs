using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class OctagonTasks : MonoBehaviour
{
    public InputField inputField;
    public InputField inputField2;

    public GameObject pictrue;
    public GameObject picfalse;
    public GameObject pictrue2;
    public GameObject picfalse2;

    float enteredValue;
    float square = 240;
    float vertex = 32;
    float perimeter = 128;
    float Bsquare = 72;
    float volume = 1152;
    float perimeterbase = 48;

    public void Check()
    {
        if (float.TryParse(inputField.text, out enteredValue))
        {
            if (Mathf.Approximately(enteredValue, vertex))
            {
                inputField.text += " Pareizi!";
                pictrue.SetActive(true);
                picfalse.SetActive(false);


            }
            else
            {
                inputField.text += " Nepareizi!";
                pictrue.SetActive(false);
                picfalse.SetActive(true);
            }
        }
    }

    public void Check2()
    {
        if (float.TryParse(inputField2.text, out enteredValue))
        {
            if (Mathf.Approximately(enteredValue, perimeter))
            {
                inputField2.text += " Pareizi!";
                pictrue2.SetActive(true);
                picfalse2.SetActive(false);


            }
            else
            {
                inputField2.text += " Nepareizi!";
                pictrue2.SetActive(false);
                picfalse2.SetActive(true);
            }
        }
    }
    public void Check3()
    {
        if (float.TryParse(inputField.text, out enteredValue))
        {
            if (Mathf.Approximately(enteredValue, Bsquare))
            {
                inputField.text += " Pareizi!";
                pictrue.SetActive(true);
                picfalse.SetActive(false);


            }
            else
            {
                inputField.text += " Nepareizi!";
                pictrue.SetActive(false);
                picfalse.SetActive(true);
            }
        }
    }
    public void Check4()
    {
        if (float.TryParse(inputField2.text, out enteredValue))
        {
            if (Mathf.Approximately(enteredValue, square))
            {
                inputField2.text += " Pareizi!";
                pictrue2.SetActive(true);
                picfalse2.SetActive(false);


            }
            else
            {
                inputField2.text += " Nepareizi!";
                pictrue2.SetActive(false);
                picfalse2.SetActive(true);
            }
        }
    }
    public void Check5()
    {
        if (float.TryParse(inputField.text, out enteredValue))
        {
            if (Mathf.Approximately(enteredValue, perimeterbase))
            {
                inputField.text += " Pareizi!";
                pictrue.SetActive(true);
                picfalse.SetActive(false);


            }
            else
            {
                inputField.text += " Nepareizi!";
                pictrue.SetActive(false);
                picfalse.SetActive(true);
            }
        }
    }
    public void Check6()
    {
        if (float.TryParse(inputField2.text, out enteredValue))
        {
            if (Mathf.Approximately(enteredValue, volume))
            {
                inputField2.text += " Pareizi!";
                pictrue2.SetActive(true);
                picfalse2.SetActive(false);


            }
            else
            {
                inputField2.text += " Nepareizi!";
                pictrue2.SetActive(false);
                picfalse2.SetActive(true);
            }
        }
    }
}
