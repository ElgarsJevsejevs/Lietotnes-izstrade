using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CreateFigureLine : MonoBehaviour
{
    public GameObject pointPrefab;
    public Transform pointParent;
    public int maxPoints = 2;

    private int pointCount = 0;
    private List<Vector3> points = new List<Vector3>();
    private LineRenderer lineRenderer;
    private bool isCreating = false;

    void Start()
    {
        if (pointParent == null)
        {
            pointParent = transform;
        }

        lineRenderer = gameObject.AddComponent<LineRenderer>();
        lineRenderer.startWidth = 1f;
        lineRenderer.endWidth = 1f;
        lineRenderer.positionCount = 0;
        lineRenderer.material = new Material(Shader.Find("Sprites/Default"));
        lineRenderer.material.color = UnityEngine.Color.black;
    }

    public void StartCreating()
    {
        lineRenderer.positionCount = 0;
        points.Clear();
        pointCount = 0;

        isCreating = true;
    }

    void Update()
    {
        if (isCreating && Input.GetMouseButtonDown(0) && pointCount < maxPoints)
        {
            Vector3 mousePos = Camera.main.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, Input.mousePosition.y, Camera.main.nearClipPlane));

            GameObject newPoint = Instantiate(pointPrefab, mousePos, Quaternion.identity, pointParent);

            points.Add(newPoint.transform.position);

            lineRenderer.positionCount = points.Count;
            lineRenderer.SetPositions(points.ToArray());

            if (pointCount == 1)
            {
                lineRenderer.positionCount++;
                lineRenderer.SetPosition(lineRenderer.positionCount - 1, points[0]);
            }

            pointCount++;
        }
    }
    public void ClearPoints2()
    {

        pointCount = 0;
        points.Clear();
        lineRenderer.positionCount = 0;

        foreach (Transform child in pointParent)
        {
            Destroy(child.gameObject);
        }

        isCreating = false;
    }
}