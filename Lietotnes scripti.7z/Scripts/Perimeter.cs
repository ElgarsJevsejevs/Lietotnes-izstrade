using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Perimeter : MonoBehaviour
{
    public float referencePerimeter;
    public Text outputField;

    private Transform cubeTransform;

    void Start()
    {
        cubeTransform = gameObject.GetComponent<Transform>();
    }

    void Update()
    {
        float perimeter = 12 * cubeTransform.localScale.x;

        outputField.text = "Perimeter: " + perimeter.ToString();

        if (Mathf.Approximately(perimeter, referencePerimeter))
        {
            outputField.text += "\nCorrect!";
        }
        else
        {
            outputField.text += "\nIncorrect!";
        }
    }
}