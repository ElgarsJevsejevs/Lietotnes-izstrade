using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cylinder : MonoBehaviour
{
    public GameObject linePrefab;
    private List<GameObject> lines = new List<GameObject>();
    public GameObject cylinder;
    public GameObject pointPrefab;
    private GameObject[] points;

    private bool pointsCreated = false;
    private bool linesCreated = false;

    public void CylinderPoints()
    {

        if (pointsCreated)
        {

            throw new InvalidOperationException("Points have already been created");
        }

        CreatePoints();
        pointsCreated = true;

    }
    public void CylinderLines()
    {

        if (linesCreated)
        {

            throw new InvalidOperationException("Lines have already been created");
        }

        CreateLines2();
        linesCreated = true;
    }

    private void Update()
    {

        UpdateLinePositions();
        UpdatePointPositions();
    }

    void CreatePoints() 
    {

        Vector3[] vertices = cylinder.GetComponent<MeshFilter>().mesh.vertices;

        points = new GameObject[vertices.Length];

        for (int i = 0; i < vertices.Length; i++)
        {
            Vector3 vertexPosition = cylinder.transform.TransformPoint(vertices[i]);
            Vector3 pointPosition = CalculatePointPosition(vertexPosition);
            Quaternion pointRotation = CalculatePointRotation(vertexPosition);
            GameObject point = AddPointToPosition(pointPosition, pointRotation);
            points[i] = point;
        }
    }


    void UpdatePointPositions()
    {

        for (int i = 0; i < points.Length; i++)
        {
            Vector3 vertexPosition = cylinder.transform.TransformPoint(cylinder.GetComponent<MeshFilter>().mesh.vertices[i]);
            Vector3 pointPosition = CalculatePointPosition(vertexPosition);
            Quaternion pointRotation = CalculatePointRotation(vertexPosition);
            points[i].transform.position = pointPosition;
            points[i].transform.rotation = pointRotation;
        }
    }

    Vector3 CalculatePointPosition(Vector3 vertexPosition)
    {

        return vertexPosition;
    }

    Quaternion CalculatePointRotation(Vector3 vertexPosition)
    {

        return Quaternion.identity;
    }

    GameObject AddPointToPosition(Vector3 position, Quaternion rotation)
    {

        return Instantiate(pointPrefab, position, rotation);
    }

    private void CreateLines2()
    {

        for (int i = 0; i < 56; i++)
        {
            for (int j = i + 1; j < 56; j++)
            {
                GameObject line = Instantiate(linePrefab);
                line.transform.parent = transform;

                LineRenderer renderer = line.GetComponent<LineRenderer>();
                renderer.startWidth = 0.05f;
                renderer.endWidth = 0.05f;
                renderer.SetPositions(new Vector3[] { points[i / 2].transform.position, points[j / 2].transform.position });

                lines.Add(line);
            }
        }
    }
    private void UpdateLinePositions()
    {

        for (int i = 0; i < lines.Count; i++)
        {
            int index1 = i / 42;
            int index2 = i % 42 + 1;
            if (index1 < points.Length && index2 < points.Length)
            {
                LineRenderer renderer = lines[i].GetComponent<LineRenderer>();
                renderer.SetPositions(new Vector3[] { points[index1].transform.position, points[index2].transform.position });
            }
        }
    }
    public void ClearPointsAndLines()
    {

        foreach (GameObject point in points)
        {
            Destroy(point);
        }


        points = new GameObject[16];


        foreach (GameObject line in lines)
        {
            Destroy(line);
        }


        lines.Clear();

        pointsCreated = false;
        linesCreated = false;
    }


}
