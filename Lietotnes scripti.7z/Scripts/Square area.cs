using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class Squarearea : MonoBehaviour
{
    public float referenceValue;
    public InputField inputField;
    private Transform cubeTransform;
    public GameObject pictrue2;
    public GameObject picfalse2;

    public InputField widthInput;
    public InputField heightInput;
    public InputField lenghtInput;

    public InputField inputField2;
    public GameObject pictrue3;
    public GameObject picfalse3;

    private Transform cylinderTransform;
    void Start()
    {

        cubeTransform = gameObject.GetComponent<Transform>();
        cylinderTransform = gameObject.GetComponent<Transform>();
    }
    public void CheckValue()
    {

        float width = float.Parse(widthInput.text);
        float height = float.Parse(heightInput.text);
        float lenght = float.Parse(lenghtInput.text);

        float area = 2 * width * lenght + 2 * width * height + 2 * lenght * height;

        float enteredValue;


        if (float.TryParse(inputField.text, out enteredValue))
        {
            if (Mathf.Approximately(enteredValue, area))
            {
                inputField.text += " Pareizi!";
                pictrue2.SetActive(true);
                picfalse2.SetActive(false);


            }
            else
            {
                inputField.text += " Nepareizi!";
                pictrue2.SetActive(false);
                picfalse2.SetActive(true);
            }
        }
    }
    public void CheckValue2()
    {

        float width = float.Parse(widthInput.text);
        float height = float.Parse(heightInput.text);
        float lenght = float.Parse(lenghtInput.text);

        float basearea = width * lenght;
        float heightS = (float)Math.Sqrt(Math.Pow(lenght / 2, 2) + Math.Pow(height, 2));
        float triarea = 0.5f * basearea * heightS;
        float area = 4 * triarea + basearea;

        string area2 = area.ToString("F1");
        float enteredValue;

            if (float.TryParse(inputField.text, out enteredValue))
            {
                if (width == height && width == lenght && height == lenght)
                {
                    if (Mathf.Approximately(enteredValue, float.Parse(area2)))
                {

                    inputField.text += " Pareizi!";
                    pictrue2.SetActive(true);
                    picfalse2.SetActive(false);


                }
                else
                {
                    inputField.text += " Nepareizi!" ;
                    pictrue2.SetActive(false);
                    picfalse2.SetActive(true);
                }
            }
            else
            {
                inputField.text += " Nav regul�rs";
            }
        }
    }
    public void CheckValue3()
    {

        float lenght = float.Parse(lenghtInput.text);
        float height = float.Parse(heightInput.text);

        float area = 2 * (1 + Mathf.Sqrt(2)) * Mathf.Pow(lenght, 2);
        string area2 = area.ToString("F1");

        float enteredValue;

        if (float.TryParse(inputField.text, out enteredValue))
        {

            if (cylinderTransform.localScale.x == cylinderTransform.localScale.y && cylinderTransform.localScale.x == cylinderTransform.localScale.z
                      && cylinderTransform.localScale.y == cylinderTransform.localScale.z)
            {
                if (Mathf.Approximately(enteredValue, float.Parse(area2)))
                {
                    inputField.text += " Pareizi!";
                    pictrue2.SetActive(true);
                    picfalse2.SetActive(false);


                }
                else
                {
                    inputField.text += " Nepareizi!";
                    pictrue2.SetActive(false);
                    picfalse2.SetActive(true);
                }
            }
            else
            {
                inputField.text += " Nav regul�rs";
            }
        }
    }

    public void CheckCapacity()
    {

        float width = float.Parse(widthInput.text);
        float height = float.Parse(heightInput.text);
        float lenght = float.Parse(lenghtInput.text);

        float basearea = width * lenght;
        float capacity = 0.3f * basearea * height;

        float enteredValue;


        if (float.TryParse(inputField2.text, out enteredValue))
        {
            if (Mathf.Approximately(enteredValue, capacity))
            {
                inputField2.text += " Pareizi!";
                pictrue3.SetActive(true);
                picfalse3.SetActive(false);


            }
            else
            {
                inputField2.text += " Nepareizi!";
                pictrue3.SetActive(false);
                picfalse3.SetActive(true);
            }
        }
    }
    public void CheckCapacity1()
    {

        float width = float.Parse(widthInput.text);
        float height = float.Parse(heightInput.text);
        float lenght = float.Parse(lenghtInput.text);

        float capacity = width * lenght * height;

        float enteredValue;

        if (float.TryParse(inputField2.text, out enteredValue))
        {
            if (Mathf.Approximately(enteredValue, capacity))
            {
                inputField2.text += " Pareizi!";
                pictrue3.SetActive(true);
                picfalse3.SetActive(false);


            }
            else
            {
                inputField2.text += " Nepareizi!";
                pictrue3.SetActive(false);
                picfalse3.SetActive(true);
            }
        }
    }

    public void CheckCapacity2()
    {

        float height = float.Parse(heightInput.text);
        float lenght = float.Parse(lenghtInput.text);

        float area = 2 * (1 + Mathf.Sqrt(2)) * Mathf.Pow(lenght, 2);

        float capacity = area * height;
        string capacity2 = capacity.ToString("F1");

        float enteredValue;

        if (float.TryParse(inputField2.text, out enteredValue))
        {
            if (cylinderTransform.localScale.x == cylinderTransform.localScale.y && cylinderTransform.localScale.x == cylinderTransform.localScale.z
                      && cylinderTransform.localScale.y == cylinderTransform.localScale.z)
            {
                if (Mathf.Approximately(enteredValue, float.Parse(capacity2)))
                {
                    inputField2.text += " Pareizi!";
                    pictrue3.SetActive(true);
                    picfalse3.SetActive(false);


                }
                else
                {
                    inputField2.text += " Nepareizi!";
                    pictrue3.SetActive(false);
                    picfalse3.SetActive(true);
                }
            }
            else
            {
                inputField2.text += " Nav regul�rs";
            }
        }
    }
}