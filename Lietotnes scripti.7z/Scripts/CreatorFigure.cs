using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using UnityEngine;
using UnityEngine.UI;

public class CreatorFigure : MonoBehaviour
{
    public GameObject pointPrefab;
    public Transform pointParent;
    public int maxPoints = 3;

    private int pointCount = 0;
    private List<Vector3> points = new List<Vector3>();
    private LineRenderer lineRenderer;
    private bool isCreating = false;

    private void Start()
    {
        if (pointParent == null)
        {
            pointParent = transform;
        }

        lineRenderer = gameObject.AddComponent<LineRenderer>();
        lineRenderer.startWidth = 1f;
        lineRenderer.endWidth = 1f;
        lineRenderer.positionCount = 0;
        lineRenderer.material = new Material(Shader.Find("Sprites/Default"));
        lineRenderer.material.color = UnityEngine.Color.black;
    }
    public void StartCreating()
    {
        isCreating = true;
    }

    private void Update()
    {
        if (isCreating && Input.GetMouseButtonDown(0) && pointCount < maxPoints)
        {
            Vector3 mousePos = Camera.main.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, Input.mousePosition.y, Camera.main.nearClipPlane));
            GameObject newPoint = Instantiate(pointPrefab, mousePos, Quaternion.identity, pointParent);
            points.Add(newPoint.transform.position);
            lineRenderer.positionCount = points.Count;
            lineRenderer.SetPositions(points.ToArray());

            if (pointCount == 2)
            {
                lineRenderer.positionCount++;
                lineRenderer.SetPosition(lineRenderer.positionCount - 1, points[0]);
            }
            pointCount++;
        }
    }
    public void ClearPoints2()
    {

        pointCount = 0;
        points.Clear();
        lineRenderer.positionCount = 0;

        foreach (Transform child in pointParent)
        {
            Destroy(child.gameObject);
        }

        isCreating = false;
    }
}
