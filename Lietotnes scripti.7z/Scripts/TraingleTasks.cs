using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TraingleTasks : MonoBehaviour
{
    public InputField inputField;
    public InputField inputField2;

    public GameObject pictrue;
    public GameObject picfalse;
    public GameObject pictrue2;
    public GameObject picfalse2;

    float enteredValue;
    float edge = 12;
    float square = 90.4f;
    float height = 4.6f;
    float perimeter = 145;
    float Bsquare = 25;
    float volume = 22.1f;

    public void Check()
    {
        if (float.TryParse(inputField.text, out enteredValue))
        {
            if (Mathf.Approximately(enteredValue, Bsquare))
            {
                inputField.text += " Pareizi!";
                pictrue.SetActive(true);
                picfalse.SetActive(false);


            }
            else
            {
                inputField.text += " Nepareizi!";
                pictrue.SetActive(false);
                picfalse.SetActive(true);
            }
        }
    }

    public void Check2()
    {
        if (float.TryParse(inputField2.text, out enteredValue))
        {
            if (Mathf.Approximately(enteredValue, square))
            {
                inputField2.text += " Pareizi!";
                pictrue2.SetActive(true);
                picfalse2.SetActive(false);


            }
            else
            {
                inputField2.text += " Nepareizi!";
                pictrue2.SetActive(false);
                picfalse2.SetActive(true);
            }
        }
    }
    public void Check3()
    {
        if (float.TryParse(inputField.text, out enteredValue))
        {
            if (Mathf.Approximately(enteredValue, edge))
            {
                inputField.text += " Pareizi!";
                pictrue.SetActive(true);
                picfalse.SetActive(false);


            }
            else
            {
                inputField.text += " Nepareizi!";
                pictrue.SetActive(false);
                picfalse.SetActive(true);
            }
        }
    }
    public void Check4()
    {
        if (float.TryParse(inputField2.text, out enteredValue))
        {
            if (Mathf.Approximately(enteredValue, perimeter))
            {
                inputField2.text += " Pareizi!";
                pictrue2.SetActive(true);
                picfalse2.SetActive(false);


            }
            else
            {
                inputField2.text += " Nepareizi!";
                pictrue2.SetActive(false);
                picfalse2.SetActive(true);
            }
        }
    }
    public void Check5()
    {
        if (float.TryParse(inputField.text, out enteredValue))
        {
            if (Mathf.Approximately(enteredValue, height))
            {
                inputField.text += " Pareizi!";
                pictrue.SetActive(true);
                picfalse.SetActive(false);


            }
            else
            {
                inputField.text += " Nepareizi!";
                pictrue.SetActive(false);
                picfalse.SetActive(true);
            }
        }
    }
    public void Check6()
    {
        if (float.TryParse(inputField2.text, out enteredValue))
        {
            if (Mathf.Approximately(enteredValue, volume))
            {
                inputField2.text += " Pareizi!";
                pictrue2.SetActive(true);
                picfalse2.SetActive(false);


            }
            else
            {
                inputField2.text += " Nepareizi!";
                pictrue2.SetActive(false);
                picfalse2.SetActive(true);
            }
        }
    }
}