using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Board : MonoBehaviour
{
    public InputField scaleInputFieldx;
    public InputField scaleInputFieldy;
    public InputField scaleInputFieldz;

    private Transform cubeTransform;

    void Start()
    {
        cubeTransform = gameObject.GetComponent<Transform>();
    }

    public void OnScaleButtonClicked()
    {
        float scalex = float.Parse(scaleInputFieldx.text);
        float scaley = float.Parse(scaleInputFieldy.text);
        float scalez = float.Parse(scaleInputFieldz.text);

        cubeTransform.localScale = new Vector3(scalex, scaley, scalez);
    }
}